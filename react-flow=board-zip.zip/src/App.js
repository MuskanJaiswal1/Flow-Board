// App.jsx
import React from 'react';
import BlockPanel from './components/BlockPanel';
import FlowCanvas from './components/FlowCanvas';
import { ReactFlowProvider } from 'react-flow-renderer';

const App = () => {
  return (
    <ReactFlowProvider>
      {/* <div className="flex h-screen"> */}
        <FlowCanvas />
        <BlockPanel />
      {/* </div> */}
    </ReactFlowProvider>
  );
};

export default App;
