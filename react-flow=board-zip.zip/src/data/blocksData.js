export const blocksList = [
  { id: '1', type: 'block', label: 'Block A' },
  { id: '2', type: 'block', label: 'Block B' },
];