import React from 'react';

const ContextMenu = ({ position, onClose }) => {
  return (
    <div
      className="absolute bg-white border shadow p-2 rounded"
      style={{ top: position.y, left: position.x }}
      onMouseLeave={onClose}
    >
      Hello World
    </div>
  );
};

export default ContextMenu;
