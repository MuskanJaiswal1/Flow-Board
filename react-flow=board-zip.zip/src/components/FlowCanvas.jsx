import React from 'react';
import ReactFlow from 'react-flow-renderer';

const elements = [
  {
    id: '1',
    type: 'default',
    position: { x: 250, y: 150 },
    data: { label: 'Hello Node' },
  },
];

const FlowCanvas = () => {
  return (
    <div style={{ width: '100%', height: '100vh', background: '#f0f0f0' }}>
      <ReactFlow elements={elements} />
    </div>
  );
};

export default FlowCanvas;
